import java.util.ArrayList;

public class Triangulation{
  
  public static ArrayList<Point> compute(ArrayList<Point> points){
    //TODO
    return null;
  }
}